import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  myimages: string = "assets/images/download.jpg";
  myimage: string = "assets/images/refrens_dark.png";
  title = 'website';
}
